function search(array, item) {
    let index = null; // 1
  
    for (
        let i = 0; //1
        i < array.length; //n+1
        i++) { //n
      if (item === array[i]) { //n
        index = i; //1 if found
        break;
      }
    }
  
    return index; //1
  }

  // n+n+(n+1)+1+1 
  // 3n + 4
  // n = 10 => 3*10 + 4 = 34


  function search(array, item) {
    let min = 0; //1
    let max = array.length - 1; //1
  
    while (true) { //lg n 
      const endIndex = mix + max; //lg n
      const middleDecimal = endIndex/2.0; //lg n
      const middleIndex = Math.floor(middleDecimal); //lg n
      const currentItem = array[middleIndex]; //lg n

      if (currentItem === item) { //lg n
        return middleIndex;
      } else if (currentItem < item) { //lg n
        min = middleIndex + 1; 
      } else {
        max = middleIndex - 1; //lg n
      }
  
      if (min > max) { //lg n
        return null; //1
      }
    }
  }

  //1+1+1+(9*log n) => 9log(n) + 3
  //3 + (9 * log 10) = 3 + (9 * 4) = 39