class Pizza {

//   constructor(size, crust) {
//     this._size = size;
//     this.crust = crust;
//     this.toppings = ["cheese"];
//   }

//   addTopping(topping) {
//     this.toppings.push(topping);
//   }

  get price() {
    const basePrice = 10;
    const toppingPrice = 2;
    return basePrice + this.toppings.length * toppingPrice;
  }

  setSize(size) {
    if (size === 's' || size === 'm' || size === 'l') {
      this._size = size;
    }
  }
}


let pizza = new Pizza();
pizza.price;
pizza.size = 's';


