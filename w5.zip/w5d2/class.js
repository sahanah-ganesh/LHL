class Person {

  constructor(name, fact) {
    this.name = name;
    this.fact = fact;
  }

  bio() {
    return `My name is ${this.name} and here's my fact: ${this.fact}`;
  }
}

class Student extends Person {

  enroll(cohort) {
    this.cohort = cohort;
  }

  bio() {
    return `I am a student at LL (aka Labber). ${super.bio()}`;
  }
}

class Mentor extends Person {

  bio() {
    return `I am a mentor ${super.bio()}`;
  }
}

let sahanah = new Student('Sahanah', 'I am cool', '123@123.com');
console.log(sahanah.bio());

// let juan = new Mentor('Juan', 'I am great');
// console.log(juan.bio());