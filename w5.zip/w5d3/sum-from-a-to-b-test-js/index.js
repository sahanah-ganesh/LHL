function sum(fromN, toN) {
  if (fromN === toN) {
    return fromN;
  } 
  return sum(fromN, toN - 1) + toN;
}

module.exports = sum;

