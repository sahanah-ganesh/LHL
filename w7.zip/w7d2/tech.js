// Given a string, return the character that appears the most # of times in the string. If there is a tie, return the first character. Ie aaaabbbbcd (return a)

let count = 0;

function multiple(string) {
  let lowerString = string.toLowerCase();
  let stringArr = lowerString.split('');

  let arrSort = stringArr.sort();

  for (let i = 0; i < arrSort.length; i++) {
    if (i === arrSort[i]) {
      count += 1;
    }
  }
}

console.log(multiple('HelLoYoUUU'));