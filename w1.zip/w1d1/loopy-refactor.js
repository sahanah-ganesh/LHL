var loopyLighthouse = function (range, multiples, words) {

  for (var i = range[0]; i <= range[1]; i++) {
    if (i % multiples[0] === 0 && i % multiples[1] === 0) {
      console.log(words[0] + words[1]);
      continue;
    } else {
      if (i % multiples[0] === 0) {
        console.log(words[0]);
        continue;
      }
      if (i % multiples[1] === 0) {
        console.log(words[1]);
        continue;
      }
    }
    console.log(i);
    continue;
  }

};