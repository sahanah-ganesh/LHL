var args = Number(process.argv[2]) + Number(process.argv[3]);
console.log(args);
