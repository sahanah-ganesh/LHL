var webApp = require("./webapp.js");

webApp.listFunction(5);
webApp.listFunction(4);
webApp.listFunction(9);

webApp.sortFunction();

