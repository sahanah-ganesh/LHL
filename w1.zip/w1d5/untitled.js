

function stdev(arr) {

  //find avg of arr (& all elements of arr & divide by arr.length)

  var avgNum = 0;
  var i;
  var avgResult;
  var k;
  var subResult;
  var sqrResult;
  var sumResult = 0;
  var addResult;
  var stdDev;

  if (!arr.length) {
    return null;
  }
  for (i = 0; i < arr.length; i++) {
    avgNum += arr[i];
  }
  avgResult = avgNum / arr.length;

  //subtract each element in arr w/number & multiply result w/self, put results in new arr

  for (k = 0; k < arr.length; k++) {
    subResult = arr[k] - avgResult;
    sqrResult = subResult * subResult;
    sumResult += sqrResult;
    console.log("sqrR", sumResult);
  }
  addResult = (sumResult) / arr.length;
  stdDev = Math.round(Math.sqrt(addResult) * 100) / 100;
  return stdDev;
}

console.log(stdev([-2,6,8,2,9]));