
module.exports = {

  list: [],

  listFunction: function(number) {
    this.list.push(number);
  },

  sortFunction: function() {
    this.list.sort(function(a, b) {
      return a - b;
    })
    console.log(this.list);
  }
};

