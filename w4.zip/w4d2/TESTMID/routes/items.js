"use strict";

const express = require('express');
const router  = express.Router();
const wolfApi = require ('../public/scripts/wolf-api.js');
const bcrypt  = require('bcrypt');


module.exports = function(knex) {

  function findItem(id) {
    return new Promise((resolve, reject) => {
      knex('items')
      .select('*')
      .where({id: id})
      .limit(1)
      .then((rows) => {
        let item = rows[0];
        if (item) {
          return resolve(item)
        }
        return reject()
      })
    })
    .catch((error) => reject(error));
  }


  function findByUser(userID) {
    return new Promise (function(resolve, reject) {

      knex('items')
      .select('*')
      .where({userID: userID})
      .then((rows) => {
        let items = rows
        return resolve(items)
      })
      .catch((error) => reject(error));
    })
  }

  function authenticateItem(userID, id) {
    return new Promise((resolve, reject) => {
      findByUser(userId)
      .then((items) => {
        if (!items) {
          return reject({
            type: 409,
            message: "Could not find"
          })
        }
        items.forEach((item) => {
          if (item.id === id) {
            return resolve(item)
          }
          return reject({
            type: 409,
            message: "Could not find"
          })
        })
      })
      .catch((error) => reject(error));
    })
  }


  function addItem(what, completed, userID, categoryID) {
    return (
      authenticateItem(userID, id)
      .then((item) => {
        return knex('items').insert({
          what: what,

        })
      })
      )

    if (userID) {
      promises.push()
    }
  return (
    findByUser(userId)
    .then(()))
  }







  return {
    find: find,
    findByEmail: findByEmail,
    authenticate: authenticate,
    add: add,
    update: update,
    checkEmailUnique: checkEmailUnique
  }

  return router;
}







