"use strict";

const express = require('express');
const router  = express.Router();
const wolfApi = require ('../public/scripts/wolf-api.js');
const bcrypt  = require('bcrypt');




module.exports = function(knex) {


  function find(id) {
    return new Promise((resolve, reject) => {
    knex('users')
      .select('*')
      .where({id: id})
      .limit(1)
      .then((rows) => {
        let user = rows[0];
        if (user) {
          return resolve(user)
        }
        return reject()
      })
    })
    .catch((error) => reject(error));
  }


  function findByEmail(email) {
  return new Promise (function(resolve, reject) {

    knex('users')
      .select('*')
      .where({email: email})
      .limit(1)
      .then((rows) => {
        let user = rows[0]
        return resolve(user)
      })
      .catch((error) => reject(error));
    })
  }

  function checkEmailUnique(email) {
    return new Promise((resolve, reject) => {
      findByEmail(email)
      .then((user) => {
        if (user) {
          return reject({
            type: 409,
            message: 'Email already in use'
          })
        }
        return resolve(email);
      })
    })
  }


  function authenticate(email, password) {
    return new Promise((resolve, reject) => {
      findByEmail(email)
      .then((user) => {
        if (!user) {
          return reject({
            type: 409,
            message: "Bad credentials"
          })
        }
        bcrypt.compare(password, user.password)
        .then((passwordsMatch) => {
          if (passwordsMatch) {
            return resolve(user)
          }
          return reject({
            type: 409,
            message: "Bad credentials"
          })
        })
      })
      .catch((error) => reject(error));
    })
  }

  function add(email, password) {
    return (
      checkEmailUnique(email)
      .then((email) => {
        return bcrypt.hash(password, 10)
      })
      .then((passwordChange) => {
        return knex('users').insert({
          email: email,
          password: passwordChange
        })
      })
    )
  }

  function update(id, newEmail, newPassword) {
    let promises = [];

    if (newEmail) {
      promises.push(checkEmailUnique(newEmail));
    }
    else {
      promises.push(Promise.resolve(false));
    }
    return Promise.all(promises).then((emailAndPasswordChange) => {
      const email = emailAndPasswordChange[0];
      const passwordChange = emailAndPasswordChange[1];

      const updatedUser = {};
      if (email) {
        updatedUser.email = email;
      }
      if (passwordChange) {
        updatedUser.password = passwordChange;
      }

      return knex('users')
      .update(updatedUser)
      .where({id: id})
    })
  }

  return {
    find: find,
    findByEmail: findByEmail,
    authenticate: authenticate,
    add: add,
    update: update,
    checkEmailUnique: checkEmailUnique
  }





// /////////////LETICIA - CREATE BUTTON/////////////

//   // get list page from user - items contents
//   router.get("/list/items", (req, res) => {
//     console.log('req.session.userId: ', req.session.userId);

//     if (!req.session.userId) {
//       res.json([]);
//     } else {
//       knex
//         .select("items.id", "what", "completed", "userID", "categoryID", "name")
//         .from("items")
//         .leftJoin('categories', 'categories.id', 'items.categoryID')
//         .where('userID', req.session.userId)
//         .orderBy('items.id')
//         .then((results) => {
//           console.log('results: ',results);
//           res.json(results);
//       });
//     }
//   });

//   // select * from "items" left join "categories" on "categories"."id" = "items"."categoryID" where "userID" = 1 order by "items"."id";


//   // create/post a new item in the list page -- replaced with AJAX code
//   router.post("/list/items", (req, res) => {

//     const what = req.body.newItem;
//     let categoryID;

//     console.log('req.session.userId: ', req.session.userId);
//     console.log('req.body: ', req.body);
//     console.log('req.body.newItem: ', req.body.newItem);

//     wolfApi.categorizer(what, (error, result) =>{
//       if (!error) {
//         console.log("Success",result.category, result.type);
//         categoryID = result.category;
//       } else if (error === "No datatypes") {
//         console.log("Search returned nothing",error, "Category =","Uncategorized");
//         categoryID = 5;
//       } else {
//         console.log("ERROR",error);
//         throw error;
//       }

//       console.log('categoryID: ', categoryID);
//       // and put that inside category field
//       knex('items')
//         .insert([{'what': what, completed: 'false', userID: req.session.userId, 'categoryID': categoryID}])
//         .then((results) => {
//           res.json(results);
//           // res.send("It's Ok!!!");
//       // render everything again/load items again --> in app.js
//         });
//     });
//   });



// /////////////LETICIA - END - CREATE BUTTON/////////////

// router.delete("/", (req, res) => {
//     console.log("started", req.body.itemId);
//     knex('items')
//       .where('id', req.body.itemId)
//       .del()
//       .then(() => res.send("Ok"))

// });


// //////////////////sahanah - edit///////////////////////



//   router.get("/list/items/:itemId/edit", (req, res) => {

//     let templateVars;

//   function editItem(itemID) {
//     knex
//       .select("items.id", "what", "completed", "userID", "categoryID", "name", 'email')
//       .from("items")
//       .leftJoin("categories", "categories.id", "items.categoryID")
//       .leftJoin("users", "users.id", "items.userID")
//       .where('userID', req.session.userId)
//       .where('items.id', itemID)
//       .then((results) => {
//         console.log('results from then: ',results);
//         templateVars = {'itemName': results[0].what,
//                         'catId': results[0].categoryID,
//                         'catName': results[0].name,
//                         'itemId':  results[0].id,
//                         'userId': req.session.userId,
//                         'email': results[0].email
//                         };
//         console.log('templateVars: ',templateVars);
//         res.render("items", templateVars);
//       })
//       .catch(error => res.status(403).send(error));
//     }
//   editItem(req.params.itemId);
//   });


//   router.post("/list/items/:itemId/edit", (req, res) => {

//     console.log("update");
//     console.log("itemID", req.params.itemId);
//     console.log("newCatID", req.body.categories);
//     console.log("itemName", req.body.newName);

//     knex("items")
//       .where("id", req.params.itemId)
//       .update({categoryID: req.body.categories, what: req.body.newName})
//       .then(() => res.redirect('/list')).catch(()=> console.log('err'));
//   });


//   router.get("/:userId/edit", (req, res) => {

//     let userEmail;
//     let userPass;
//     let templateVars;

//     console.log("userId", req.session.userId);

//     function editProfile(userID) {
//       knex
//         .select("id", "email", "password")
//         .from("users")
//         .then((results) => {
//           results.forEach(function(user) {
//             console.log("user", user);
//             if(user.id == req.session.userId) {
//               userEmail = user.email;
//               userPass = user.password;
//               templateVars = { 'email': userEmail,
//                                'userPass': userPass,
//                                'userId': req.session.userId};
//             }
//           });
//           console.log('templateVars', templateVars);
//           res.render("profile", templateVars);
//         });
//       }
//       editProfile(req.params.userId);
//   });

//   router.post("/:userId/edit", (req, res) => {
//     console.log("params", req.params.userId);
//     console.log('pass', req.body.userPass);
//     let newPass = hasher(req.body.userPass);
//     knex("users")
//       .where("id", req.params.userId)
//       .update({password: newPass})
//       .then(() => res.redirect('/list')).catch(()=> console.log('err'));
//   });



  return router;
};


