"use strict";

require('dotenv').config();

const PORT           = process.env.PORT || 8080;
const ENV            = process.env.ENV || "development";

const express        = require("express");
const bodyParser     = require("body-parser");
const sass           = require("node-sass-middleware");
const cookieSession  = require('cookie-session');

const flash          = require('connect-flash');
const knexConfig     = require("./knexfile");
const knex           = require("knex")(knexConfig[ENV]);

const User           = require("./routes/users")(knex);

const app            = express();

app.set("view engine", "ejs");

if (ENV === 'development') {
  const morgan = require('morgan');
  app.use(morgan('dev'));
  const knexLogger = require('knex-logger');
  app.use(knexLogger(knex));
}

app.use(cookieSession({
  name: 'session',
  keys: ['Smart is the way'],
  // Cookie Options
  maxAge: 24 * 60 * 60 * 1000 // 24 hours
}));

app.use(flash());

app.use(bodyParser.urlencoded({ extended: true }));

app.use("/styles", sass({
  src: __dirname + "/styles",
  dest: __dirname + "/public/styles",
  debug: true,
  outputStyle: 'expanded'
}));

app.use(express.static("public"));


function authMiddleware(req, res, next) {
  if (!req.session.userId && req.path !== '/login') {
    req.user = null;
    req.redirect('home')
    return
  }

  User.find(req.session.userId)
  .then((user) => {
    req.user = user
    next()
  })
  .catch(() => {
    req.user = null
    next()
  })
}

app.use(authMiddleware);



app.get("/", (req, res) => {
  res.render("home", {
    errors: req.flash('errors'),
    info: req.flash('info'),
    user: req.user
  })
});


app.post("/profile", (req, res) => {
  User.update(req.session.userId, req.body.email, req.body.password)
  .then(() => {
    req.flash('info', 'Updated your profile');
    res.redirect('/');
  }).catch((error) => {
    req.flash('errors', error.message);
    res.redirect('/');
  });
});


app.get("/login", (req, res) => {
  res.render('login');
});

app.get('/register', (req, res) => {
  res.render('register');
});

app.get("/logout", (req, res) => {
  req.session = undefined;
  res.redirect('/');
});


app.post('/login', (req, res, next) => {
  User.authenticate(req.body.email, req.body.password)
  .then((user) => {
    req.session.userId = user.id;
    res.redirect('/');
  }).catch((error) => {
    req.flash('errors', error.message);
    res.redirect('/');
  });
});


app.post('/register', (req, res) => {
  if (!req.body.email || !req.body.password) {
    req.flash('errors', 'Email and password are required');
    res.redirect('/');
    return;
  }
  User.add(req.body.email, req.body.password)
  .then(() => {
    req.flash('info', 'Account successfully created');
    res.redirect('/login');
  }).catch((error) => {
    req.flash('errors', error.message);
    res.redirect('/');
  });
});



// app.get("/list", (req, res) => {
//   findEmail(req.session.userId)
//     .then(userData => {
//       const templateVars = {  'userId': req.session.userId,
//                               'email': userData.email,
//                             };
//       console.log('templateVars: ',templateVars);
//       res.render("list", templateVars);
//     })
//     .catch(error => res.status(403).send(error));
// });



// // get/redirect user to the edit item page
// app.get("/items/:itemID", (req, res) => {
//   res.redirect("items");
// });



app.listen(PORT, () => {
  console.log("Example app listening on port " + PORT);
});
