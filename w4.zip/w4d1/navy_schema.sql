DROP TABLE IF EXISTS sailor CASCADE;
DROP TABLE IF EXISTS assignment CASCADE;
DROP TABLE IF EXISTS rank CASCADE;
DROP TABLE IF EXISTS ship CASCADE;
DROP TABLE IF EXISTS fleet CASCADE;

CREATE TABLE fleet (
  id SERIAL PRIMARY KEY NOT NULL,
  name VARCHAR(50) NOT NULL
);

CREATE TABLE ship (
  id SERIAL PRIMARY KEY NOT NULL,
  name VARCHAR(50) NOT NULL,
  build_date DATE NOT NULL,
  fleet_id VARCHAR(50) NOT NULL
);

CREATE TABLE rank (
  id SERIAL PRIMARY KEY NOT NULL,
  name VARCHAR(50) NOT NULL
);

CREATE TABLE assignment (
  name VARCHAR(50) NOT NULL,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  ship_id INTEGER NOT NULL,
  rank_id INTEGER NOT NULL,
  sailor_id INTEGER NOT NULL
);

CREATE TABLE sailor (
  id SERIAL PRIMARY KEY NOT NULL,
  name VARCHAR(50) NOT NULL,
  birthday DATE NOT NULL
);


INSERT INTO sailor (id, name, birthday) VALUES (1, 'Amy', '1991-01-01');
INSERT INTO sailor (id, name, birthday) VALUES (2, 'Barbara', '1992-02-02');
INSERT INTO sailor (id, name, birthday) VALUES (3, 'Cathy', '1993-03-03');

INSERT INTO assignment (name, start_date, end_date, ship_id, rank_id, sailor_id) VALUES ('Alpha', '2010-01-01', '2011-01-01', 1, 1, 1);
INSERT INTO assignment (name, start_date, end_date, ship_id, rank_id, sailor_id) VALUES ('Bravo', '2011-01-01', '2012-01-01', 2, 2, 2);
INSERT INTO assignment (name, start_date, end_date, ship_id, rank_id, sailor_id) VALUES ('Charlie', '2012-01-01', '2013-01-01', 3, 3, 3);

INSERT INTO rank (id, name) VALUES (1, 'A');
INSERT INTO rank (id, name) VALUES (2, 'B');
INSERT INTO rank (id, name) VALUES (3, 'C');

INSERT INTO ship (id, name, build_date, fleet_id) VALUES (1, 'Auto', '1995-01-01', 1);
INSERT INTO ship (id, name, build_date, fleet_id) VALUES (2, 'Bot', '1994-01-01', 1);
INSERT INTO ship (id, name, build_date, fleet_id) VALUES (3, 'Cat', '1993-01-01', 1);

INSERT INTO fleet (id, name) VALUES (1, 'Freedom');

