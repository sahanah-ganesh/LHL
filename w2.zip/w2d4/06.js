var contacts = [
  {
    name: "Laurel",
    phone: "123 456 7890",
    email: "laurel@comics.com",
    friends: ["Hardy", "Abbott", "Costello"]
  },
  {
    name: "Hardy",
    phone: "321 654 0987",
    email: "hardy@hardyharhar.com",
    friends: ["Laurel", "Buster"]
  },
  {
    name: "Buster",
    phone: "987 654 3210",
    email: "buster@keaton.ca",
    friends: ["Hardy"]
  },
  {
    name: "Abbott",
    phone: "888 123 4567",
    email: "abbott@whosonfirst.co",
    friends: ["Costello", "Laurel"]
  },
  {
    name: "Costello",
    phone: "767 676 7676",
    email: "costello@imonfirst.co",
    friends: ["Abbott", "Laurel"]
  }
];

/* You should be changing this code */

function findFriend(data, name, field) {

  let resultObj = {};
  let friendObj = {};

  const contact = function(name, data) {
    for (let i = 0; i < data.length; i++) {
      if (name === data[i].name) {
        resultObj["name"] = data[i].friends[0];
      }
    }
    return resultObj;
  }

  let friendName = resultObj.name;

  const friendData = function(friendName, data) {
    for (let j = 0; j < data.length; j++) {
      if (friendName === data[j].name) {
        friendObj = data[j];
      }
    }
    return friendObj;
  }


  const method = function(field, friendData) {
    for (let key in friendObj) {
      if (field === key) {
        resultObj[field] = friendObj[key];
      }
    }
    return resultObj;
  }

  if (!contact || !method) {
    return "Not Found";
  }
  return method();
}

console.log(findFriend(contacts, "Abbott", "phone"));
console.log(findFriend(contacts, "Buster", "email"));
console.log ( findFriend(contacts, "Bob", "phone")  );
console.log ( findFriend(contacts, "Costello", "birthday")  );

