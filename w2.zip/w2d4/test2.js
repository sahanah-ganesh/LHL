const urlDatabase = {
  b6UTxQ: { longURL: "https://www.tsn.ca",
            userID: "aJ48lW" },
  i3BoGr: { longURL: "https://www.google.ca",
            userID: "aJ48lW" },
  abc:    { longURL: "google",
            userID: "hello" },
  def:    { longURL: "what",
            userID: "why"}
};

function urlsForUser(id) {

  // let userID = "aJ48lW";

  let urlsObj = {};

  for (var shortURL in urlDatabase) {
    if (urlDatabase[shortURL]["userID"] === id) {
      urlsObj[shortURL] = urlDatabase[shortURL];
    }
  }
  return urlsObj;
};

console.log(urlsForUser("aJ48lW"));