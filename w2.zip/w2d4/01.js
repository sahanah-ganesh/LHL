"use strict";

/* Question 01

Build a function called keyMatcher() which, when passed two objects and a string,
will use the string to look up the key-value pair in each object and compare the values.
If the two values are explicitly equal to each other, return true, otherwise return false
if either the values or not the same, or both objects do not have that key.

Examples:

- keyMatcher({a: 1, b: 2, c: 3}, {this: 3, is: 2, a: 1, silly: 0, example: -1}, 'a')
returns true (since the value and type is the exact same)

- keyMatcher({apple: "red", banana: "yellow", cherry: "red"}, {apple: "green", banana: "brown", cherry: "black"}, "apple")
returns false since the values are completely different ("red" vs "green")

- keyMatcher({a: 1, b: 2, c: 3}, {a: "1", b: "2", c: "3"}, 'c')
returns false since the values are different types (3 vs "3")

- keyMatcher({a: 1, b: 2, c: 3}, {d: 4, e: 5, f: 6}, 'b')
returns false since b is not in the second object

*/

// function keyMatcher(firstObj, secondObj, key) {

function keyMatcher(firstObj, secondObj, key) {

  let firstArr = Object.entries(firstObj);
  let firstMatch = [];

  let secondArr = Object.entries(secondObj);
  let secondMatch = [];

  for (var i = 0; i < firstArr.length; i++) {
    if (key === firstArr[i][0]) {
      firstMatch.push(firstArr[i]);
    }
  }
  console.log(firstMatch);

  for (var k = 0; k < secondArr.length; k++) {
    if (key === secondArr[k][0]) {
      secondMatch.push(secondArr[k]);
    }
  }
  console.log(secondMatch);

  if(firstMatch == false || secondMatch == false) {
    return false;
  }

  let firstValue = firstMatch[0][1];
  let secondValue = secondMatch[0][1];

  console.log(firstValue);
  console.log(secondValue);

  if (firstValue === secondValue && typeof firstValue === typeof secondValue) {
    return true;
  } else {
    return false;
  }
}


console.log( keyMatcher( {a: 1, b: 2, c: 3}, {this: 3, is: 2, a: 1, silly: 0, example: -1}, 'a')  );
console.log( keyMatcher({apple: "red", banana: "yellow", cherry: "red"}, {apple: "green", banana: "brown", cherry: "black"}, "apple") );
console.log( keyMatcher({a: 1, b: 2, c: 3}, {a: "1", b: "2", c: "3"}, 'c')    );
console.log( keyMatcher({a: 1, b: 2, c: 3}, {d: 4, e: 5, f: 6}, 'b') );
// Don't change below:

module.exports = { keyMatcher };