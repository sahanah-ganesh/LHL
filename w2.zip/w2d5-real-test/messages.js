module.exports = {
  UsageInstructions: `Usage:\n\tnpm run test {Test#}\nEx: npm run test 1`,
  StudentIdWarning: "Enter a unique Student Id in the file .student-id"
};
